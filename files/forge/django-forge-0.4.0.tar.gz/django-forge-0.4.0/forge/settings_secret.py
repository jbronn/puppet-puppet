SECRET_KEY = '!!0jsp5h)$4r0uz)(p6@c9b0$gv0^o$woi%!oncjsz74*1dlfa'
